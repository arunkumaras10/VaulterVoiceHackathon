package com.kainosdub.rpbank;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.RequestBody;

public class Utilities {
    public static RequestBody jsonToRequestBody(String json) {
        try {
            RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),(new JSONObject(json)).toString());
            return body;
        } catch (JSONException e) {
            return null;
        }
    }

    public static RequestBody jsonToRequestBody(JSONObject json) {
        RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json; charset=utf-8"),json.toString());
        return body;
    }
}

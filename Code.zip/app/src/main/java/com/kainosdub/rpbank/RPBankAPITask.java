package com.kainosdub.rpbank;

import org.json.JSONObject;

import java.util.concurrent.Callable;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RPBankAPITask implements Callable<String> {
    private JSONObject jsonPayload;
    private Retrofit retrofit;
    private final String API_URL = "http://events.respark.iitm.ac.in:5000/";
    private RPBankService rpBankService;

    public RPBankAPITask(JSONObject jsonPayload) {
        this.jsonPayload = jsonPayload;
        retrofit = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        rpBankService = retrofit.create(RPBankService.class);
    }

    @Override
    public String call() throws Exception {
        RequestBody body = Utilities.jsonToRequestBody(jsonPayload);
        Call<ResponseBody> call = rpBankService.post(body);
        Response<ResponseBody> response = call.execute();
        return response.body().string();
    }
}
